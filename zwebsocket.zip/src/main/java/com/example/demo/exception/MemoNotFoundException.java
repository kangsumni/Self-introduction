package com.example.demo.exception;

public class MemoNotFoundException extends RuntimeException {
}

package com.example.demo.controller.memo;

import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@PreAuthorize("isAuthenticated()")
@Controller
public class MemoViewController {
	// 받은 메모함
	@GetMapping("/memo/receive")
	public String 수신메모() {
		return "memo/receive";
	}
	
	// 보낸 메모함
	@GetMapping("/memo/send")
	public String 송신메모() {
		return "memo/send";
	}
	
	@GetMapping("/memo/read")
	public String 메모읽기() {
		return "memo/read";
	}
}

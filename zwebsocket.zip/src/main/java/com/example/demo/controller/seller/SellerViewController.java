package com.example.demo.controller.seller;

import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Secured("ROLE_SELLER")
@Controller
public class SellerViewController {
	@GetMapping("/seller/list")
	public String 예약리스트() {
		return "seller/list";
	}
	
	@GetMapping("/seller/send_all")
	public String 전체메시지() {
		return "seller/send_all";
	}
}

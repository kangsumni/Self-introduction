package com.example.demo.controller.all;

import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
public class AllViewController {
	@GetMapping("/")
	public String 루트페이지() {
		return "index";
	}
}

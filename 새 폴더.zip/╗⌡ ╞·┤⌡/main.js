// 모달 열기
function modalOpen() {
    document.querySelector('.modal_wrap').style.display = 'block';
    document.querySelector('.modal_background').style.display = 'block';
}

// 모달 끄기
function modalClose() {
    document.querySelector('.modal_wrap').style.display = 'none';
    document.querySelector('.modal_background').style.display = 'none';
}


//버튼 클릭리스너 달기
document.querySelector('#modal_btn').addEventListener('click', modalOpen);
document.querySelector('.modal_close').addEventListener('click', modalClose);


//리뷰작성버튼 클릭리스너 기
document.querySelector('#modal_btn').addEventListener('click', modalOpen);
document.querySelector('.reviewButton').addEventListener('click', modalClose);

$(".starC").on("click", function(){
    let a =$(this).attr("value");
    $(".star1").html('☆');
    $(".star2").html('☆');
    $(".star3").html('☆');
    $(".star4").html('☆');
    $(".star5").html('☆');

    if(a==1){
        $(".star1").html("★");
    }else if(a==2){
        $(".star1").html('★');
        $(".star2").html('★');
    }else if(a==3){
        $(".star1").html('★');
        $(".star2").html('★');
        $(".star3").html('★');
    }else if(a==4){
        $(".star1").html('★');
        $(".star2").html('★');
        $(".star3").html('★');
        $(".star4").html('★');
    }else if(a==5){
        $(".star1").html('★');
        $(".star2").html('★');
        $(".star3").html('★');
        $(".star4").html('★');
        $(".star5").html('★');
    }
});

